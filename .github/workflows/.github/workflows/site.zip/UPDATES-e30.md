# v30
- About page: new optional "Support this project" card with a JazzCash number and a Copy button.
- Service-worker cache bumped to english-notes-v30.
