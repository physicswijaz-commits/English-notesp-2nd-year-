/* ==========================================================================
   Service worker — makes English Notes work fully offline once visited once.
   Bump CACHE_NAME whenever site files change so old caches get replaced.
   ========================================================================== */
const CACHE_NAME = 'english-lite-v1';

const PRECACHE_URLS = [
  './',
  'index.html',
  'vocabulary.html',
  'flashcards.html',
  'bookmarks.html',
  'about.html',
  'privacy.html',
  'terms.html',
  'me.html',
  'manifest.json',
  'assets/css/style.css?v=e6',
  'assets/js/app.js',
  'assets/js/bookmarks.js',
  'assets/js/chapters-data.js',
  'assets/js/extras.js',
  'assets/js/flashcards.js',
  'assets/js/highlight.js',
  'assets/js/layout.js',
  'assets/js/nav-scroll.js',
  'assets/js/page-transitions.js',
  'assets/js/quiz.js',
  'assets/js/related.js',
  'assets/js/ripple.js',
  'assets/js/search-index.js',
  'assets/js/srs.js',
  'assets/js/theme.js',
  'assets/js/vocab-data.js',
  'assets/js/vocab.js',
  'assets/icons/apple-touch-icon.png',
  'assets/icons/icon-192.png',
  'assets/icons/icon-512-maskable.png',
  'assets/icons/icon-512.png',
  'assets/img/me.jpg',
  'ch1.html',
  'ch2.html',
  'ch3.html',
  'ch4.html',
  'ch5.html',
  'ch6.html',
  'ch7.html',
  'ch8.html',
  'ch9.html',
  'ch10.html',
  'ch11.html',
  'ch12.html',
  'ch13.html',
  'ch14.html',
  'ch15.html',
  'ch16.html',
  'ch17.html',
  'ch18.html',
  'ch19.html'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(PRECACHE_URLS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((names) =>
      Promise.all(names.filter((n) => n !== CACHE_NAME).map((n) => caches.delete(n)))
    ).then(() => self.clients.claim())
  );
});

/* Cache-first for same-origin requests (the whole site), so it works with
   zero connectivity. Cross-origin requests (Google Fonts, the Lucide icon
   CDN) are just passed through to the network — if they fail offline, the
   site already degrades gracefully without them. */
self.addEventListener('fetch', (event) => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  event.respondWith(
    caches.match(req, { ignoreSearch: true }).then((cached) => {
      if (cached) return cached;
      return fetch(req).then((res) => {
        if (res && res.status === 200) {
          const clone = res.clone();
          caches.open(CACHE_NAME).then((cache) => cache.put(req, clone));
        }
        return res;
      }).catch(() => cached);
    })
  );
});
