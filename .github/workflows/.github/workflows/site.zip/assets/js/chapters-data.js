/* Shared chapter metadata — single source of truth for the homepage tile grid
   and the "Related Chapters" widget on lesson pages. Keep in sync with the
   `chapters` array in index.html if a chapter's title/theme/type/page changes. */
const CHAPTERS_DATA = [
  { no: 1, file: "ch1.html", title: "Seerat-e-Tayyiba and the Muslim Youth", theme: "Character building", type: "Prose", page: 1 },
  { no: 2, file: "ch2.html", title: "Jinnah's Vision of Pakistan", theme: "Tolerance, humanism, equality between groups and nation", type: "Prose", page: 16 },
  { no: 3, file: "ch3.html", title: "Solitary Reaper (Poem)", theme: "Appreciation and preservation of nature", type: "Poem", page: 26 },
  { no: 4, file: "ch4.html", title: "Truck Art", theme: "Respect for all professions (Valuing disparity and equality among professions)", type: "Prose", page: 32 },
  { no: 5, file: "ch5.html", title: "The Last Leaf", theme: "Humanism", type: "Prose", page: 42 },
  { no: 6, file: "ch6.html", title: "If (Poem)", theme: "Character building", type: "Poem", page: 53 },
  { no: 7, file: "ch7.html", title: "Hubble", theme: "Technology and society of future", type: "Prose", page: 61 },
  { no: 8, file: "ch8.html", title: "Lesson from the Battle of Uhud", theme: "Duties and Responsibilities", type: "Prose", page: 77 },
  { no: 9, file: "ch9.html", title: "The Toys (Poem)", theme: "Mercy/compassion/forgiveness/divine love", type: "Poem", page: 85 },
  { no: 10, file: "ch10.html", title: "Gender Inequality and its Implications", theme: "Gender inequality is detrimental to society", type: "Prose", page: 92 },
  { no: 11, file: "ch11.html", title: "Jahangir Khan The Conqueror", theme: "Rise of Nations through National Pride", type: "Prose", page: 101 },
  { no: 12, file: "ch12.html", title: "All the World's a Stage (Poem)", theme: "Transiency", type: "Poem", page: 110 },
  { no: 13, file: "ch13.html", title: "Technical Education", theme: "Life Skills Education", type: "Prose", page: 119 },
  { no: 14, file: "ch14.html", title: "Lingkuan Gorge", theme: "Duty and Responsibility", type: "Prose", page: 130 },
  { no: 15, file: "ch15.html", title: "Once Upon a Time (Poem)", theme: "Practicing adaptability/Social etiquettes", type: "Poem", page: 140 },
  { no: 16, file: "ch16.html", title: "Tourist Attractions in Pakistan", theme: "Tourism, Its Impact on Society", type: "Prose", page: 150 },
  { no: 17, file: "ch17.html", title: "Désirée's Baby", theme: "Equality/Fraternity/Humanism", type: "Prose", page: 162 },
  { no: 18, file: "ch18.html", title: "Lines from the Deserted Village (Poem)", theme: "Love of nature/preservation of nature", type: "Poem", page: 176 },
  { no: 19, file: "ch19.html", title: "Lord of the Flies", theme: "Civilization and Savagery", type: "Prose", page: 184 }
];
