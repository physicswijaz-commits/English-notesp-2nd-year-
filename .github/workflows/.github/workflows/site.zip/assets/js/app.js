/* ==========================================================================
      — Shared behaviour
   Runs on every page. Each block feature-detects the elements it needs, so
   the same file safely serves the homepage,  (sidebar) pages and
   / (single-column) pages without errors.
   ========================================================================== */

/* ---------- PWA: offline caching + installability ---------- */
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('service-worker.js').catch(() => {
      /* offline caching just won't be available this session — the site
         still works normally online, so fail silently */
    });
  });
}

document.addEventListener('DOMContentLoaded', () => {

  /* ---------- Icons ---------- */
  if (window.lucide) lucide.createIcons();

  /* ---------- Attribution watermark (home / vocab / flashcards only) ----------
     Lesson pages (//) intentionally have no footer any more — it's
     one of the utility elements (footer, back-top, tab-bar) kept on the
     homepage and stripped from lesson pages to reduce clutter there. */
  if (!document.body.classList.contains('lesson')) (function ensureWatermark() {
    /* old 'Created by' watermark removed in v29 — the site-wide footer (layout.js) replaces it */
  })();

  /* ----------   (streak) tracking — runs on every page ---------- */
  const VISIT_DATES_KEY = 'visitDates';
  function todayKey() {
    const d = new Date();
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function dateKeyFromTimestamp(ts) {
    const d = new Date(ts);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  function recordTodayVisit() {
    let dates = [];
    try { dates = JSON.parse(localStorage.getItem(VISIT_DATES_KEY) || '[]'); } catch (e) { dates = []; }
    const set = new Set(dates);
    set.add(todayKey());
    localStorage.setItem(VISIT_DATES_KEY, JSON.stringify([...set]));
    return set;
  }
  function computeStreak(dateSet) {
    let streak = 0;
    const cursor = new Date();
    /* Count backwards from today; a missed day breaks the chain. */
    for (;;) {
      const key = cursor.getFullYear() + '-' + String(cursor.getMonth() + 1).padStart(2, '0') + '-' + String(cursor.getDate()).padStart(2, '0');
      if (dateSet.has(key)) { streak++; cursor.setDate(cursor.getDate() - 1); }
      else break;
    }
    return streak;
  }
  const visitDates = recordTodayVisit();

  /* ----------     — practice-mode toggle (/ pages) ---------- */
  const practiceToggle = document.getElementById('practice-toggle');
  if (practiceToggle) {
    const explanationBlocks = document.querySelectorAll('.mafhoom-block, .tashreeh-block');
    explanationBlocks.forEach((block) => {
      const textEl = block.querySelector('.mafhoom-text, .tashreeh-text');
      if (!textEl) return;
      const revealBtn = document.createElement('button');
      revealBtn.type = 'button';
      revealBtn.className = 'exam-reveal-btn';
      revealBtn.innerHTML = '<i data-lucide="eye"></i>Tap to reveal';
      revealBtn.addEventListener('click', () => block.classList.remove('practice-hidden'));
      block.appendChild(revealBtn);
    });
    if (window.lucide) lucide.createIcons();

    practiceToggle.addEventListener('click', () => {
      const active = document.documentElement.classList.toggle('practice-mode');
      practiceToggle.classList.toggle('active', active);
      practiceToggle.setAttribute('aria-pressed', active ? 'true' : 'false');
      /* Re-arm every block hidden each time practice mode is (re)started. */
      explanationBlocks.forEach((block) => {
        if (active) block.classList.add('practice-hidden');
        else block.classList.remove('practice-hidden');
      });
    });
  }

  /* Theme (light/sepia/dark) is now handled entirely by theme.js — the
     <head> inline snippet applies the saved class before paint, and
     theme.js wires up the .theme-dot switcher. This file still needs
     `root` below for font-size and focus-mode toggles. */
  const root = document.documentElement;

  /* ---------- Q&A accordion (accessible, CSS-driven animation) ---------- */
  document.querySelectorAll('.qa-question').forEach((question) => {
    question.setAttribute('role', 'button');
    question.setAttribute('tabindex', '0');
    question.setAttribute('aria-expanded', 'false');

    const card = question.closest('.qa-card');
    const answer = question.nextElementSibling;
    if (answer && !answer.id) {
      answer.id = 'qa-answer-' + Math.random().toString(36).slice(2, 9);
    }
    if (answer) question.setAttribute('aria-controls', answer.id);

    const toggle = () => {
      const isOpen = card.classList.toggle('open');
      question.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    };

    question.addEventListener('click', toggle);
    question.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'Spacebar') {
        e.preventDefault();
        toggle();
      }
    });
  });

  /* ---------- Scroll-driven UI: progress bar + back-to-top ---------- */
  const progressBar = document.getElementById('progress');
  const backTop = document.getElementById('back-top');

  if (progressBar || backTop) {
    let ticking = false;
    const updateOnScroll = () => {
      const doc = document.documentElement;
      const scrollable = doc.scrollHeight - doc.clientHeight;
      const pct = scrollable > 0 ? (doc.scrollTop / scrollable) * 100 : 0;

      if (progressBar) progressBar.style.width = pct + '%';
      if (backTop) backTop.classList.toggle('show', doc.scrollTop > 400);
      ticking = false;
    };

    window.addEventListener('scroll', () => {
      if (!ticking) {
        window.requestAnimationFrame(updateOnScroll);
        ticking = true;
      }
    }, { passive: true });

    updateOnScroll();
  }

  if (backTop) {
    backTop.setAttribute('aria-label', 'Back to top');
    backTop.addEventListener('click', () => {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
  }

  /* ---------- Mobile sidebar drawer ( pages only) ---------- */
  const sidebar = document.getElementById('sidebar');
  const backdrop = document.getElementById('backdrop');
  const menuToggle = document.getElementById('menu-toggle');
  const sidebarClose = document.getElementById('sidebar-close');

  if (sidebar && backdrop && menuToggle) {
    let scrollY = 0;

    const openSidebar = () => {
      scrollY = window.scrollY;
      document.body.style.top = -scrollY + 'px';
      document.body.classList.add('drawer-lock');
      sidebar.classList.add('open');
      backdrop.classList.add('open');
      menuToggle.setAttribute('aria-expanded', 'true');
    };
    const closeSidebar = () => {
      sidebar.classList.remove('open');
      backdrop.classList.remove('open');
      menuToggle.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('drawer-lock');
      document.body.style.top = '';
      window.scrollTo(0, scrollY);
    };

    menuToggle.setAttribute('aria-label', 'Open chapter menu');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.addEventListener('click', openSidebar);
    backdrop.addEventListener('click', closeSidebar);
    if (sidebarClose) sidebarClose.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('a').forEach((a) => a.addEventListener('click', closeSidebar));
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') closeSidebar();
    });
  }

  /* ---------- Scrollspy: highlight the active sidebar link ( pages) ---------- */
  const topics = document.querySelectorAll('section.topic');
  const sideLinks = document.querySelectorAll('#sidebar nav a');

  if (topics.length && sideLinks.length && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          sideLinks.forEach((l) => l.classList.remove('active'));
          const active = document.querySelector(`#sidebar nav a[href="#${entry.target.id}"]`);
          if (active) active.classList.add('active');
        }
      });
    }, { rootMargin: '-40% 0px -50% 0px', threshold: 0 });

    topics.forEach((section) => observer.observe(section));
  }

  /* ---------- Reading tools: font-size cycle (small ↔ normal ↔ large) ---------- */
  const fontToggle = document.getElementById('font-toggle');
  if (fontToggle) {
    const sizes = ['', 'text-lg', 'text-sm'];
    const labels = { '': 'A', 'text-lg': 'A+', 'text-sm': 'A-' };
    let current = localStorage.getItem('fontScale') || '';
    if (!sizes.includes(current)) current = '';

    function applyFontScale(size) {
      root.classList.remove('text-lg', 'text-sm');
      if (size) root.classList.add(size);
      fontToggle.textContent = labels[size];
      fontToggle.setAttribute('aria-label', 'Text size: ' + (size === 'text-lg' ? 'large' : size === 'text-sm' ? 'small' : 'normal') + ' \u2014 tap to change');
    }

    applyFontScale(current);
    fontToggle.addEventListener('click', () => {
      current = sizes[(sizes.indexOf(current) + 1) % sizes.length];
      localStorage.setItem('fontScale', current);
      applyFontScale(current);
    });
  }

  /* ---------- Reading tools: focus mode (hide header + sidebar) ---------- */
  const focusToggle = document.getElementById('focus-toggle');
  const focusExit = document.getElementById('focus-exit');
  {
    const applyFocus = (on) => {
      root.classList.toggle('focus-mode', on);
      if (focusToggle) {
        focusToggle.classList.toggle('active', on);
        focusToggle.setAttribute('aria-pressed', on ? 'true' : 'false');
        focusToggle.setAttribute('aria-label', on ? 'Exit focus mode' : 'Focus mode \u2014 hide sidebar and header');
      }
    };
    applyFocus(localStorage.getItem('focusMode') === 'true');
    if (focusToggle) {
      focusToggle.addEventListener('click', () => {
        const on = !root.classList.contains('focus-mode');
        localStorage.setItem('focusMode', on ? 'true' : 'false');
        applyFocus(on);
      });
    }
    if (focusExit) {
      focusExit.addEventListener('click', () => {
        localStorage.setItem('focusMode', 'false');
        applyFocus(false);
      });
    }
  }

  /* ---------- Mark this chapter as read + reflect on homepage ---------- */
  function getReadSet() {
    try { return new Set(JSON.parse(localStorage.getItem('readPages') || '[]')); }
    catch (e) { return new Set(); }
  }
  function saveReadSet(set) { localStorage.setItem('readPages', JSON.stringify([...set])); }

  const readToggle = document.getElementById('read-toggle');
  if (readToggle) {
    const page = location.pathname.split('/').pop();
    const label = readToggle.querySelector('span');
    const setState = (done) => {
      readToggle.classList.toggle('done', done);
      readToggle.setAttribute('aria-pressed', done ? 'true' : 'false');
      if (label) label.textContent = done ? 'Marked as read \u2713' : 'Mark as read';
      const icon = readToggle.querySelector('[data-lucide]');
      if (icon) { icon.setAttribute('data-lucide', done ? 'check-check' : 'check'); if (window.lucide) lucide.createIcons(); }
    };
    const readSet = getReadSet();
    setState(readSet.has(page));
    readToggle.addEventListener('click', () => {
      const set = getReadSet();
      const done = !set.has(page);
      if (done) set.add(page); else set.delete(page);
      saveReadSet(set);
      setState(done);
    });
  }

  /* ---------- " " — resume scroll position + track last-opened lesson ---------- */
  const LESSON_PROGRESS_KEY = 'chapterProgress';
  function getLessonProgress() {
    try { return JSON.parse(localStorage.getItem(LESSON_PROGRESS_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function saveLessonProgress(data) { localStorage.setItem(LESSON_PROGRESS_KEY, JSON.stringify(data)); }

  if (readToggle) { /* readToggle only exists on  pages, so this is our lesson-page gate */
    const page = location.pathname.split('/').pop();
    const titleEl = document.querySelector('.chapter-header h1, .hero-title');
    const poetEl = document.querySelector('.chapter-header p, .hero-poet');
    const title = titleEl ? titleEl.textContent.trim() : '';
    const poet = poetEl ? poetEl.textContent.trim() : '';

    const existingAll = getLessonProgress();
    const existing = existingAll[page];

    function showResumeToast() {
      const toast = document.createElement('div');
      toast.className = 'resume-toast';
      toast.innerHTML = '<i data-lucide="corner-up-left"></i><span>Jumped back to where you left off</span><button aria-label="Dismiss">×</button>';
      document.body.appendChild(toast);
      if (window.lucide) lucide.createIcons();
      requestAnimationFrame(() => requestAnimationFrame(() => toast.classList.add('show')));
      const dismiss = () => { toast.classList.remove('show'); setTimeout(() => toast.remove(), 300); };
      toast.querySelector('button').addEventListener('click', dismiss);
      setTimeout(dismiss, 3500);
    }

    /* Restore scroll position once, only if we were meaningfully partway through
       and the lesson isn't already marked  (checked fresh, in case the user
       toggled it in a previous tab/session). Wait a tick for fonts/layout to settle
       so the % maps onto the correct pixel height. */
    if (existing && existing.pct > 3 && existing.pct < 96 && !getReadSet().has(page)) {
      setTimeout(() => {
        const doc = document.documentElement;
        const scrollable = doc.scrollHeight - doc.clientHeight;
        if (scrollable > 0) {
          window.scrollTo({ top: (existing.pct / 100) * scrollable, behavior: 'auto' });
          showResumeToast();
        }
      }, 120);
    }

    /* Record this visit immediately (updates "last opened" even if the user
       never scrolls), keeping whatever % was already stored. */
    (function recordVisit() {
      const all = getLessonProgress();
      const prev = all[page] || {};
      all[page] = { pct: prev.pct || 0, lastOpened: Date.now(), title, poet };
      saveLessonProgress(all);
    })();

    /* Keep the % (and last-opened timestamp) fresh as the person scrolls. */
    let progressTicking = false;
    function recordScrollProgress() {
      if (document.body.classList.contains('x-in-mashq')) { progressTicking = false; return; } /*  tab has its own height */
      const doc = document.documentElement;
      const scrollable = doc.scrollHeight - doc.clientHeight;
      const pct = scrollable > 0 ? Math.min(100, Math.max(0, Math.round((doc.scrollTop / scrollable) * 100))) : 0;
      const all = getLessonProgress();
      all[page] = { pct, lastOpened: Date.now(), title, poet };
      saveLessonProgress(all);
      progressTicking = false;
    }
    window.addEventListener('scroll', () => {
      if (!progressTicking) { window.requestAnimationFrame(recordScrollProgress); progressTicking = true; }
    }, { passive: true });
    window.addEventListener('pagehide', recordScrollProgress);
  }

  /* ---------- Swipe between lessons + discoverable / hint ---------- */
  if (readToggle) {
    const page = location.pathname.split('/').pop();
    const m = page.match(/^ch(\d+)\.html$/);
    if (m) {
      const num = parseInt(m[1], 10);
      let prevPage = null, nextPage = null;
      if (num > 1) prevPage = 'ch' + (num - 1) + '.html';
      if (num < 19) nextPage = 'ch' + (num + 1) + '.html';

      /* Discoverable hint row, bottom of the lesson — works even if swiping
         is never discovered. */
      const mainEl = document.querySelector('main');
      if (mainEl && (prevPage || nextPage)) {
        const nav = document.createElement('div');
        nav.className = 'lesson-nav-hint';
        nav.innerHTML =
          (prevPage
            ? '<a href="' + prevPage + '" class="lesson-nav-btn prev"><i data-lucide="arrow-left"></i><span>Previous chapter</span></a>'
            : '<span></span>') +
          (nextPage
            ? '<a href="' + nextPage + '" class="lesson-nav-btn next"><span>Next chapter</span><i data-lucide="arrow-right"></i></a>'
            : '<span></span>');
        mainEl.appendChild(nav);
        if (window.lucide) lucide.createIcons();
      }

      /* Swipe gesture. RTL page-turning convention: dragging right-to-left
         (swipe left) moves forward to the next lesson — the same motion as
         turning a page forward; dragging left-to-right (swipe right) goes back. */
      let touchStartX = 0, touchStartY = 0, touchActive = false;
      window.addEventListener('touchstart', (e) => {
        if (document.body.classList.contains('drawer-lock')) return; /* drawer open — ignore */
        if (e.touches.length !== 1) return;
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        touchActive = true;
      }, { passive: true });

      window.addEventListener('touchend', (e) => {
        if (!touchActive) return;
        touchActive = false;
        const touch = e.changedTouches[0];
        const dx = touch.clientX - touchStartX;
        const dy = touch.clientY - touchStartY;
        if (Math.abs(dx) < 70 || Math.abs(dx) < Math.abs(dy) * 1.4) return; /* too short, or mostly vertical scroll */
        if (dx < 0 && nextPage) window.location.href = nextPage;
        else if (dx > 0 && prevPage) window.location.href = prevPage;
      }, { passive: true });
    }
  }

  /* ---------- Homepage: progress summary + read badges on cards ---------- */
  const cardGrids = document.querySelectorAll('.card-grid');
  if (cardGrids.length) {
    const readSet = getReadSet();
    const cards = document.querySelectorAll('.card.ready');
    let readCount = 0;
    cards.forEach((card) => {
      const href = card.getAttribute('href');
      if (href && readSet.has(href)) { card.classList.add('is-read'); readCount++; }
    });

    const hero = document.querySelector('.hero');
    if (hero && cards.length) {
      const pct = Math.round((readCount / cards.length) * 100);
      /* Progress ring lives inside the hero markup itself (see index.html) —
         just update its stroke + numbers instead of injecting a bar. */
      const ring = document.getElementById('progress-ring');
      const ringNum = document.getElementById('progress-num');
      const ringDenom = document.getElementById('progress-denom');
      if (ring) {
        const circumference = 2 * Math.PI * 35; /* r=35, matches the SVG circle */
        ring.style.strokeDashoffset = String(circumference - (pct / 100) * circumference);
      }
      if (ringNum) ringNum.textContent = String(readCount);
      if (ringDenom) ringDenom.textContent = '/' + cards.length;
    }

    /* ---------- Homepage: " " continue card ---------- */
    const lessonProgress = getLessonProgress();
    let mostRecent = null;
    Object.keys(lessonProgress).forEach((p) => {
      if (readSet.has(p)) return; /* already  — nothing to continue */
      const entry = lessonProgress[p];
      if (!entry || !entry.lastOpened) return;
      if (!mostRecent || entry.lastOpened > mostRecent.entry.lastOpened) mostRecent = { page: p, entry };
    });

    if (mostRecent && hero) {
      const cdd = (typeof CHAPTERS_DATA !== 'undefined') ? CHAPTERS_DATA.filter((c) => c.file === mostRecent.page)[0] : null; const prefix = cdd && cdd.type === 'Poem' ? 'nazam' : 'nasr';
      const pct = Math.max(mostRecent.entry.pct || 0, 1);
      const card = document.createElement('a');
      card.className = 'continue-card type-' + prefix;
      card.href = mostRecent.page;
      card.innerHTML =
        '<span class="continue-card-top">' +
          '<span class="continue-card-label"><i data-lucide="rotate-ccw"></i>Continue reading</span>' +
          '<i data-lucide="arrow-right"></i>' +
        '</span>' +
        '<span class="continue-card-title">' + (mostRecent.entry.title || '') + '</span>' +
        '<span class="continue-card-poet">' + (mostRecent.entry.poet || mostRecent.entry.theme || '') + '</span>' +
        '<span class="continue-card-progress">' +
          '<span class="continue-card-bar"><span class="continue-card-bar-fill" style="width:' + pct + '%"></span></span>' +
          '<span class="continue-card-pct">' + pct + '% read</span>' +
        '</span>';
      hero.insertAdjacentElement('afterend', card);
      if (window.lucide) lucide.createIcons();
    }

    /* ---------- Homepage:    (daily streak + today's touched lessons) ---------- */
    if (hero) {
      const streak = computeStreak(visitDates);
      const tKey = todayKey();
      const touchedToday = Object.values(lessonProgress).filter(
        (e) => e && e.lastOpened && dateKeyFromTimestamp(e.lastOpened) === tKey
      ).length;

      const goalBox = document.createElement('div');
      goalBox.className = 'goal-widget';
      goalBox.innerHTML =
        '<div class="goal-stat">' +
          '<span class="goal-num"><i data-lucide="flame"></i>' + streak + '</span>' +
          '<span class="goal-label">day streak</span>' +
        '</div>' +
        '<div class="goal-divider"></div>' +
        '<div class="goal-stat">' +
          '<span class="goal-num">' + touchedToday + '</span>' +
          '<span class="goal-label">chapters today</span>' +
        '</div>';
      hero.insertAdjacentElement('afterend', goalBox);
      if (window.lucide) lucide.createIcons();
    }
  }

  /* ---------- Gentle scroll-reveal for reading blocks ---------- */
  const revealTargets = document.querySelectorAll('section.topic, .sher-block');
  if (revealTargets.length && 'IntersectionObserver' in window && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    const revealer = new IntersectionObserver((entries, obs) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) { entry.target.classList.add('in-view'); obs.unobserve(entry.target); }
      });
    }, { rootMargin: '0px 0px -8% 0px', threshold: 0.01 });
    revealTargets.forEach((el) => revealer.observe(el));
  }

  /* ---------- Bottom tab bar: active state + search-tab focus behaviour ---------- */
  const tabBar = document.querySelector('.tab-bar');
  if (tabBar) {
    document.body.classList.add('has-tab-bar');
    const page = location.pathname.split('/').pop() || 'index.html';
    const activeMap = { 'index.html': 'home', '': 'home', 'vocabulary.html': 'vocab', 'flashcards.html': 'flashcards', 'bookmarks.html': 'bookmarks', 'me.html': 'me' };
    const activeTab = activeMap[page];
    if (activeTab) {
      const activeEl = tabBar.querySelector('[data-tab="' + activeTab + '"]');
      if (activeEl) activeEl.classList.add('active');
    }

    const searchTab = tabBar.querySelector('[data-tab="search"]');
    const headerSearch = document.getElementById('search');
    if (searchTab && headerSearch) {
      /* Already on the homepage — just focus the existing box instead of reloading it. */
      searchTab.addEventListener('click', (e) => {
        e.preventDefault();
        headerSearch.focus();
        headerSearch.scrollIntoView({ behavior: 'smooth', block: 'center' });
      });
    }
  }

  /* Arrived on the homepage via the  tab from another page — focus the search box. */
  if (document.getElementById('search') && location.search.indexOf('focus=search') !== -1) {
    const searchInput = document.getElementById('search');
    setTimeout(() => {
      searchInput.focus();
      searchInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 150);
  }
});
