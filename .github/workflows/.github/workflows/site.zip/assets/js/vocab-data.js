const VOCAB_CORE = [
  {
    "word": "Accession",
    "meaning": "Gaining a new position or office.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Adherence",
    "meaning": "Sticking firmly to a rule, belief, or cause.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Austerity",
    "meaning": "Living a very simple life without extra money, comforts, or goods.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Beacon",
    "meaning": "A tower with a bright light that guides people or ships; a source of guidance.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Chastity",
    "meaning": "Purity, modesty, and staying away from bad acts.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Dynamic",
    "meaning": "Very active, full of energy and new ideas.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Sagaciously",
    "meaning": "Doing something very wisely and smartly.",
    "chapter": 1,
    "chapterTitle": "Seerat-e-Tayyiba and the Muslim Youth",
    "source": "chapter"
  },
  {
    "word": "Sovereign",
    "meaning": "Independent; having the highest power and authority.",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Jobbery",
    "meaning": "Using a public government office to make private, illegal profit.",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Nepotism",
    "meaning": "Favoring your own relatives or friends by giving them jobs.",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Bury the hatchet",
    "meaning": "To make peace and forget old arguments.",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Hindrance",
    "meaning": "An obstacle; something that blocks your path or slows you down.",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Sub-continent",
    "meaning": "A large landmass that forms part of a continent (referring to India/Pakistan).",
    "chapter": 2,
    "chapterTitle": "Jinnah's Vision of Pakistan",
    "source": "chapter"
  },
  {
    "word": "Solitary",
    "meaning": "Alone; without company.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Melancholy",
    "meaning": "A feeling of quiet, gentle sadness.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Profound",
    "meaning": "Very deep (here, describing the deep valley).",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Plaintive",
    "meaning": "Sounding sad or mournful.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Lay",
    "meaning": "A short song or poem, especially one that is sung.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Chaunt",
    "meaning": "An old spelling of \"chant\" — to sing in a simple, repeated tune.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Sickle",
    "meaning": "A curved hand tool with a sharp blade, used for cutting grain.",
    "chapter": 3,
    "chapterTitle": "Solitary Reaper (Poem)",
    "source": "chapter"
  },
  {
    "word": "Kaleidoscope",
    "meaning": "A constantly changing pattern of bright, brilliant colors.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Guild",
    "meaning": "An association or group of skilled craftsmen working together.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Lavished",
    "meaning": "Spent a very large amount of money or effort on something.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Illiterate",
    "meaning": "Unable to read or write.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Indestructible",
    "meaning": "So strong that it cannot be destroyed.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Transience",
    "meaning": "Lasting only for a short time; not permanent.",
    "chapter": 4,
    "chapterTitle": "Truck Art",
    "source": "chapter"
  },
  {
    "word": "Pneumonia",
    "meaning": "A serious sickness of the lungs that makes it hard to breathe.",
    "chapter": 5,
    "chapterTitle": "The Last Leaf",
    "source": "chapter"
  },
  {
    "word": "Masterpiece",
    "meaning": "The greatest and most beautiful piece of work an artist ever creates.",
    "chapter": 5,
    "chapterTitle": "The Last Leaf",
    "source": "chapter"
  },
  {
    "word": "Vine",
    "meaning": "A plant that grows up a wall or tree (like the ivy plant in the story).",
    "chapter": 5,
    "chapterTitle": "The Last Leaf",
    "source": "chapter"
  },
  {
    "word": "Willpower",
    "meaning": "The strong desire and mental strength to do something, like the desire to stay alive.",
    "chapter": 5,
    "chapterTitle": "The Last Leaf",
    "source": "chapter"
  },
  {
    "word": "Impostors",
    "meaning": "Fakes; cheats; things that pretend to be real but are not.",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Knaves",
    "meaning": "Dishonest, bad, or tricky people.",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Pitch-and-toss",
    "meaning": "A game of chance or a big risk.",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Sinew",
    "meaning": "The strong tissue that connects muscles to bones (meaning physical strength).",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Virtue",
    "meaning": "Good moral character and purity.",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Unforgiving minute",
    "meaning": "Time that never waits for anyone and cannot be brought back.",
    "chapter": 6,
    "chapterTitle": "If (Poem)",
    "source": "chapter"
  },
  {
    "word": "Multitude",
    "meaning": "A very large number of something.",
    "chapter": 7,
    "chapterTitle": "Hubble",
    "source": "chapter"
  },
  {
    "word": "Tenous",
    "meaning": "Very weak, thin, or slight.",
    "chapter": 7,
    "chapterTitle": "Hubble",
    "source": "chapter"
  },
  {
    "word": "Supernova",
    "meaning": "A huge, spectacular explosion of a massive star.",
    "chapter": 7,
    "chapterTitle": "Hubble",
    "source": "chapter"
  },
  {
    "word": "Exoplanet",
    "meaning": "A planet that orbits a star outside our own solar system.",
    "chapter": 7,
    "chapterTitle": "Hubble",
    "source": "chapter"
  },
  {
    "word": "Transit",
    "meaning": "When a smaller object (like a planet) passes in front of a larger object (like a star).",
    "chapter": 7,
    "chapterTitle": "Hubble",
    "source": "chapter"
  },
  {
    "word": "Annihilate",
    "meaning": "To destroy something completely.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Belligerent",
    "meaning": "Hostile and aggressive; ready to fight.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Besiege",
    "meaning": "To surround a place with armed forces.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Bewilderment",
    "meaning": "A strong feeling of being confused.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Comrades-in-arms",
    "meaning": "Fellow soldiers who share the same dangers.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Consternation",
    "meaning": "A feeling of anxiety or fear at something unexpected.",
    "chapter": 8,
    "chapterTitle": "Lesson from the Battle of Uhud",
    "source": "chapter"
  },
  {
    "word": "Dismiss'd",
    "meaning": "Sent away (to bed).",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Slumbering",
    "meaning": "Sleeping deeply.",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Abraded",
    "meaning": "Rubbed smooth by the sand and sea water.",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Tranced breath",
    "meaning": "The final, frozen breath at the time of death.",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Vexing",
    "meaning": "Annoying, troubling, or making someone angry.",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Wrath",
    "meaning": "Extreme, heavy anger.",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Moulded from the clay",
    "meaning": "Created from dirt/mud (referring to how God created human beings).",
    "chapter": 9,
    "chapterTitle": "The Toys (Poem)",
    "source": "chapter"
  },
  {
    "word": "Ascribe",
    "meaning": "To blame someone or something as the cause.",
    "chapter": 10,
    "chapterTitle": "Gender Inequality and its Implications",
    "source": "chapter"
  },
  {
    "word": "Abode",
    "meaning": "A home or place where someone lives.",
    "chapter": 10,
    "chapterTitle": "Gender Inequality and its Implications",
    "source": "chapter"
  },
  {
    "word": "Conspicuously",
    "meaning": "Very clearly or easily seen.",
    "chapter": 10,
    "chapterTitle": "Gender Inequality and its Implications",
    "source": "chapter"
  },
  {
    "word": "Dearth",
    "meaning": "A severe lack or shortage of something.",
    "chapter": 10,
    "chapterTitle": "Gender Inequality and its Implications",
    "source": "chapter"
  },
  {
    "word": "Consequently",
    "meaning": "As a result of something.",
    "chapter": 10,
    "chapterTitle": "Gender Inequality and its Implications",
    "source": "chapter"
  },
  {
    "word": "Fertile",
    "meaning": "Capable of producing great results (like good soil for plants).",
    "chapter": 11,
    "chapterTitle": "Jahangir Khan The Conqueror",
    "source": "chapter"
  },
  {
    "word": "Disparaging",
    "meaning": "Saying negative or discouraging things to make someone feel weak.",
    "chapter": 11,
    "chapterTitle": "Jahangir Khan The Conqueror",
    "source": "chapter"
  },
  {
    "word": "Consecutively",
    "meaning": "One after another without stopping (like his 555 wins).",
    "chapter": 11,
    "chapterTitle": "Jahangir Khan The Conqueror",
    "source": "chapter"
  },
  {
    "word": "Demise",
    "meaning": "A person's death.",
    "chapter": 11,
    "chapterTitle": "Jahangir Khan The Conqueror",
    "source": "chapter"
  },
  {
    "word": "Bade adieu",
    "meaning": "Said goodbye to (when he retired from playing).",
    "chapter": 11,
    "chapterTitle": "Jahangir Khan The Conqueror",
    "source": "chapter"
  },
  {
    "word": "Mewling",
    "meaning": "Crying weakly like a baby.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Puking",
    "meaning": "Vomiting or throwing up.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Satchel",
    "meaning": "A small bag used for carrying school books.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Pard",
    "meaning": "Leopard (showing he is wild and aggressive).",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Capon",
    "meaning": "A fat, high-quality chicken.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Saws",
    "meaning": "Old, wise sayings or proverbs.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Oblivion",
    "meaning": "The state of forgetting everything; total blankness.",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Sans",
    "meaning": "A French word meaning \"without.\"",
    "chapter": 12,
    "chapterTitle": "All the World's a Stage (Poem)",
    "source": "chapter"
  },
  {
    "word": "Demographic",
    "meaning": "Relating to the structure of the population (like age or numbers).",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Vocational",
    "meaning": "Education or training directed at a particular practical job or skill.",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Aggravate",
    "meaning": "To make a bad situation even worse.",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Alleviate",
    "meaning": "To make pain or a problem (like poverty) less severe.",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Obsessed",
    "meaning": "Thinking about something constantly to an unhealthy degree.",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Cohort",
    "meaning": "A group of people sharing a common feature (like people of the same age).",
    "chapter": 13,
    "chapterTitle": "Technical Education",
    "source": "chapter"
  },
  {
    "word": "Gorge",
    "meaning": "A narrow valley between hills or mountains.",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Obliterated",
    "meaning": "Completely destroyed or wiped out (hidden from view).",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Ravine",
    "meaning": "A very deep, narrow ditch or valley.",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Imp",
    "meaning": "A mischievous or naughty little child.",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Discern",
    "meaning": "To see, recognize, or understand something clearly.",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Knock off",
    "meaning": "To stop working at the end of a shift.",
    "chapter": 14,
    "chapterTitle": "Lingkuan Gorge",
    "source": "chapter"
  },
  {
    "word": "Ice-block-cold eyes",
    "meaning": "Eyes that have zero emotion, love, or warmth.",
    "chapter": 15,
    "chapterTitle": "Once Upon a Time (Poem)",
    "source": "chapter"
  },
  {
    "word": "Good-riddance",
    "meaning": "A feeling of relief when someone annoying finally leaves.",
    "chapter": 15,
    "chapterTitle": "Once Upon a Time (Poem)",
    "source": "chapter"
  },
  {
    "word": "Muting things",
    "meaning": "Bad habits that silence or kill true, natural feelings.",
    "chapter": 15,
    "chapterTitle": "Once Upon a Time (Poem)",
    "source": "chapter"
  },
  {
    "word": "Fangs",
    "meaning": "The long, sharp, poisonous teeth of a snake.",
    "chapter": 15,
    "chapterTitle": "Once Upon a Time (Poem)",
    "source": "chapter"
  },
  {
    "word": "Conforming",
    "meaning": "Changing yourself to match what other people are doing.",
    "chapter": 15,
    "chapterTitle": "Once Upon a Time (Poem)",
    "source": "chapter"
  },
  {
    "word": "Kaleidoscope",
    "meaning": "A beautiful, changing pattern of different shapes and colors.",
    "chapter": 16,
    "chapterTitle": "Tourist Attractions in Pakistan",
    "source": "chapter"
  },
  {
    "word": "Melting pot",
    "meaning": "A place where different people, religions, and cultures mix together happily.",
    "chapter": 16,
    "chapterTitle": "Tourist Attractions in Pakistan",
    "source": "chapter"
  },
  {
    "word": "Fauna / Avifauna",
    "meaning": "The animals and birds of a specific region.",
    "chapter": 16,
    "chapterTitle": "Tourist Attractions in Pakistan",
    "source": "chapter"
  },
  {
    "word": "Verdant",
    "meaning": "Green with rich, healthy grass and plants.",
    "chapter": 16,
    "chapterTitle": "Tourist Attractions in Pakistan",
    "source": "chapter"
  },
  {
    "word": "Amity",
    "meaning": "Friendship, peace, and good relations between people.",
    "chapter": 16,
    "chapterTitle": "Tourist Attractions in Pakistan",
    "source": "chapter"
  },
  {
    "word": "Foundling",
    "meaning": "An abandoned baby found with unknown parents.",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Prejudice",
    "meaning": "An unfair, negative opinion about someone formed without real reason.",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Cradle",
    "meaning": "A small bed for a baby, often one that can be gently rocked.",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Nameless",
    "meaning": "Having no known family name or origin.",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Irony",
    "meaning": "A twist where the actual truth is the opposite of what was believed.",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Condescension",
    "meaning": "A superior, looking-down attitude toward someone seen as \"lesser.\"",
    "chapter": 17,
    "chapterTitle": "D&eacute;sir&eacute;e's Baby",
    "source": "chapter"
  },
  {
    "word": "Auburn",
    "meaning": "The name of the beautiful, imaginary village in the poem.",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  },
  {
    "word": "Swain",
    "meaning": "A young country man or farm worker.",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  },
  {
    "word": "Cot",
    "meaning": "A small house or cottage.",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  },
  {
    "word": "Fled",
    "meaning": "Gone away or disappeared.",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  },
  {
    "word": "Peasantry",
    "meaning": "Poor farmers and hardworking country people.",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  },
  {
    "word": "Accumulates",
    "meaning": "Gathers or increases in huge amounts (like wealth).",
    "chapter": 18,
    "chapterTitle": "Lines from the Deserted Village (Poem)",
    "source": "chapter"
  }
];
