/* ==========================================================================
   Spaced repetition engine — shared by the Vocabulary Bank (vocab.js) and
   Flashcards (flashcards.js). Simplified Leitner system:
     - A word graded "Got It" moves up a level, so it comes back after a
       longer gap next time.
     - A word graded "Still Learning" drops back to level 0, so it comes
       back soon (within the hour).
     - A word that has never been graded is always "due" — new words show
       up for review until you've answered them at least once.
   Storage: localStorage 'vocabSRS' = { "word-lowercase": { level, due, last } }
   Loaded before vocab.js / flashcards.js on both pages that need it.
   ========================================================================== */
const VocabSRS = (function () {
  const STORAGE_KEY = 'vocabSRS';
  const HOUR = 60 * 60 * 1000;
  // Gap before a word becomes due again, indexed by level (0 = just learned).
  const LEVEL_GAPS_HOURS = [4, 24, 3 * 24, 7 * 24, 14 * 24, 30 * 24];
  const RELEARN_GAP_HOURS = 1; // "Still Learning" comes back within the hour

  function load() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); }
    catch (e) { return {}; }
  }
  function save(state) { localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }

  function keyFor(word) { return String(word).trim().toLowerCase(); }

  /* Reads straight from a state object (pass one you already loaded, so a
     render loop doesn't hit localStorage once per word). */
  function isDue(state, word) {
    const rec = state[keyFor(word)];
    if (!rec) return true;
    return Date.now() >= rec.due;
  }

  /* Has this word ever been graded at least once? (Used to decide whether
     to show a "Due" badge — brand-new words are due by default, but that's
     not worth badging on every single untouched word.) */
  function hasHistory(state, word) {
    return !!state[keyFor(word)];
  }

  function grade(word, knewIt) {
    const state = load();
    const key = keyFor(word);
    const rec = state[key] || { level: -1 };
    const level = knewIt ? Math.min(rec.level + 1, LEVEL_GAPS_HOURS.length - 1) : 0;
    const gapHours = knewIt ? LEVEL_GAPS_HOURS[level] : RELEARN_GAP_HOURS;
    state[key] = {
      level,
      due: Date.now() + gapHours * HOUR,
      last: knewIt ? 'know' : 'learning',
      gradedAt: Date.now()
    };
    save(state);
    return state[key];
  }

  /* Counts how many of the given word strings are currently due. */
  function dueCount(words) {
    const state = load();
    let n = 0;
    words.forEach((w) => { if (isDue(state, w)) n++; });
    return n;
  }

  return { load, save, keyFor, isDue, hasHistory, grade, dueCount };
})();
