/* ==========================================================================
      — Extras (v22)
   Everything here feature-detects its page, uses localStorage only, and adds
   no new lesson content.
     • " " notice when the site updates
     • Home: exam countdown, today's revision, weak Q&A, install / share / backup
     • Lesson: reading time, report-a-mistake link
   ========================================================================== */
(function () {
  'use strict';

  var GTITLES = {};
  var CONTACT_WA = '923409368103';           /* WhatsApp number (country code, no +) */
  var WORDS_PER_MIN = 150;                   /* Urdu reading speed used for the time chip */
  var BACKUP_KEYS = ['readPages', 'quizProgress', 'chapterProgress', 'visitDates', 'flashcardProgress',
                     'srsProgress', 'myVocab', 'fontScale', 'theme', 'focusMode', 'examDate'];

  function get(key, fallback) { try { var v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); } catch (e) { return fallback; } }
  function put(key, val) { try { localStorage.setItem(key, JSON.stringify(val)); } catch (e) {} }
  function icons() { if (window.lucide) try { lucide.createIcons(); } catch (e) {} }
  function el(html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; }
  function esc(s) { return String(s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
  function toast(msg) {
    document.querySelectorAll('.x-toast').forEach(function (t) { t.remove(); });
    var t = el('<div class="x-toast" role="status">' + esc(msg) + '</div>'); document.body.appendChild(t);
    setTimeout(function () { t.classList.add('out'); setTimeout(function () { t.remove(); }, 300); }, 2600);
  }
  function dayNum(d) { return Math.floor(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()) / 864e5); }

  /* ---------- 1. update notice ---------- */
  if ('serviceWorker' in navigator) {
    var hadController = !!navigator.serviceWorker.controller;
    navigator.serviceWorker.addEventListener('controllerchange', function () {
      if (!hadController || document.querySelector('.x-update')) return;
      var bar = el('<div class="x-update" role="status"><span>A new version is available</span><button type="button">Refresh</button></div>');
      bar.querySelector('button').onclick = function () { location.reload(); };
      document.body.appendChild(bar);
    });
  }

  document.addEventListener('DOMContentLoaded', function () {
    if (document.body.classList.contains('home')) initHome();
    if (document.body.classList.contains('lesson') && document.getElementById('read-toggle')) initLesson();
  });

  /* ---------- 2. home ---------- */
  function initHome() {
    var anchor = document.querySelector('.ios-quick-list');
    if (!anchor) return;
    var wrap = el('<div class="x-home"></div>');

    /* exam countdown */
    var saved = get('examDate', '');
    wrap.appendChild(el(
      '<div class="x-card x-exam"><span class="x-ic"><i data-lucide="calendar-days"></i></span>' +
      '<div class="x-tx"><b>Exam date</b><small id="x-exam-sub"></small></div>' +
      '<label class="x-date"><span>Pick date</span><input type="date" id="x-exam-date" aria-label="Exam date"></label></div>'));
    anchor.parentNode.insertBefore(wrap, anchor);
    var input = wrap.querySelector('#x-exam-date'), sub = wrap.querySelector('#x-exam-sub');
    input.value = saved;
    function paintExam() {
      var v = input.value;
      if (!v) { sub.textContent = 'Tap here to set the date (also in the ≡ menu)'; return; }
      var p = v.split('-').map(Number), left = dayNum(new Date(p[0], p[1] - 1, p[2])) - dayNum(new Date());
      sub.textContent = left > 0 ? 'Exam in ' + left + ' days left' : left === 0 ? 'Exam is today — good luck!' : 'Date has passed — set a new one in the ≡ menu';
    }
    input.onchange = function () { if (input.value) put('examDate', input.value); else localStorage.removeItem('examDate'); paintExam(); toast('Exam date saved'); };
    paintExam();
    wrap.firstChild.style.cursor = 'pointer';
    wrap.firstChild.addEventListener('click', function () { var m = document.getElementById('x-menu'); if (m) m.click(); });

    /* today's revision (vocab words already reviewed and now due) + weak Q&A */
    var srs = get('srsProgress', {}), now = Date.now(), due = 0;
    Object.keys(srs).forEach(function (w) { if (srs[w] && srs[w].next && srs[w].next <= now) due++; });
    var qs = get('quizProgress', {}), weak = [], weakTotal = 0, cnt = {};
    Object.keys(qs).forEach(function (k) { if (qs[k] === 'learning') { var pg = k.split('#')[0]; cnt[pg] = (cnt[pg] || 0) + 1; } });
    Object.keys(cnt).forEach(function (pg) { weakTotal += cnt[pg]; weak.push({ page: pg, n: cnt[pg] }); });
    weak.sort(function (a, b) { return b.n - a.n; });
    if (due || weakTotal) {
      var rows = '';
      if (due) rows += '<a class="x-row" href="flashcards.html"><i data-lucide="layers"></i><span><b>Words to review today: ' + due + '</b><small>Open flashcards</small></span><i data-lucide="chevron-right"></i></a>';
      weak.slice(0, 3).forEach(function (w) {
        var c = document.querySelector('a.card[href="' + w.page + '"] .card-title');
        rows += '<a class="x-row" href="' + esc(w.page) + '#short-q"><i data-lucide="pencil-line"></i><span><b>' + esc(c ? c.textContent : (GTITLES[w.page] || w.page)) + '</b><small>' + w.n + ' questions still learning</small></span><i data-lucide="chevron-right"></i></a>';
      });
      wrap.appendChild(el('<div class="x-card x-today"><h3><i data-lucide="target"></i> Today’s review' + (weakTotal ? ' <em>' + weakTotal + ' weak questions</em>' : '') + '</h3>' + rows + '</div>'));
    }

    /* footer tools: install, share, backup */
    var footer = document.querySelector('footer');
    var tools = el(
      '<div class="x-tools"><button type="button" id="x-install" hidden><i data-lucide="download"></i><span>Install app</span></button>' +
      '<button type="button" id="x-share"><i data-lucide="share-2"></i><span>Share with friends</span></button>' +
      '<button type="button" id="x-backup"><i data-lucide="download"></i><span>Back up progress</span></button>' +
      '<button type="button" id="x-restore"><i data-lucide="upload"></i><span>Restore backup</span></button>' +
      '<input type="file" id="x-file" accept="application/json,.json" hidden></div>');
    if (footer) footer.parentNode.insertBefore(tools, footer); else document.body.appendChild(tools);

    var deferred = null;
    window.addEventListener('beforeinstallprompt', function (e) { e.preventDefault(); deferred = e; tools.querySelector('#x-install').hidden = false; });
    tools.querySelector('#x-install').onclick = function () { if (!deferred) return; deferred.prompt(); deferred.userChoice.finally(function () { deferred = null; tools.querySelector('#x-install').hidden = true; }); };
    tools.querySelector('#x-share').onclick = function () {
      var url = new URL('index.html', location.href).href, text = 'English Notes for 2nd Year — chapters, vocabulary bank and flashcards';
      if (navigator.share) navigator.share({ title: 'English Notes', text: text, url: url }).catch(function () {});
      else if (navigator.clipboard) navigator.clipboard.writeText(text + '\n' + url).then(function () { toast('Link copied'); }, function () { toast('Could not copy'); });
    };
    tools.querySelector('#x-backup').onclick = function () {
      var data = { app: 'urdu-notes', version: 1, saved: new Date().toISOString(), keys: {} };
      BACKUP_KEYS.forEach(function (k) { var v = localStorage.getItem(k); if (v !== null) data.keys[k] = v; });
      var a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([JSON.stringify(data)], { type: 'application/json' }));
      a.download = 'urdu-notes-backup-' + new Date().toISOString().slice(0, 10) + '.json'; document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(a.href); }, 2000); toast('Backup file saved');
    };
    tools.querySelector('#x-restore').onclick = function () { tools.querySelector('#x-file').click(); };
    tools.querySelector('#x-file').onchange = function (e) {
      var f = e.target.files && e.target.files[0]; if (!f) return; var r = new FileReader();
      r.onload = function () {
        try {
          var d = JSON.parse(r.result); if (!d || d.app !== 'urdu-notes' || !d.keys) throw 0;
          if (!confirm('Your current study record will be replaced by the backup. Continue?')) return;
          BACKUP_KEYS.forEach(function (k) { if (typeof d.keys[k] === 'string') localStorage.setItem(k, d.keys[k]); });
          toast('Restored'); setTimeout(function () { location.reload(); }, 700);
        } catch (err) { toast('This file is not a valid backup'); }
      };
      r.readAsText(f); e.target.value = '';
    };
    icons();
  }

  /* ---------- 3. lesson ---------- */
  function initLesson() {
    var rt = document.getElementById('read-toggle'), host = rt.parentNode, main = document.querySelector('main');
    var words = (main ? main.innerText : '').split(/\s+/).filter(Boolean).length;
    var mins = Math.max(1, Math.round(words / WORDS_PER_MIN));
    var title = (document.querySelector('h1') || {}).textContent || document.title;
    var msg = 'Hi! I noticed a mistake in English Notes \u2014 \u201c' + title.trim() + '\u201d (' + location.pathname.split('/').pop() + '):\n';
    icons();
  }
})();
