/* ---------- "Related Chapters" — shown at the bottom of each lesson ----------
   Scores every other chapter against the current one (same type scores higher,
   shared theme keywords add a bit more) and shows the top 3 as small link cards,
   encouraging connected revision instead of isolated lesson-by-lesson reading. */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof CHAPTERS_DATA === 'undefined') return;
  const grid = document.getElementById('related-grid');
  const section = document.getElementById('related');
  if (!grid || !section) return;

  const page = location.pathname.split('/').pop();
  const current = CHAPTERS_DATA.find((c) => c.file === page);
  if (!current) { section.remove(); return; }

  const STOP_WORDS = new Set(['and', 'the', 'of', 'in', 'its', 'a', 'for', 'to', 'is', 'through']);
  function keywords(theme) {
    return theme.toLowerCase().replace(/[()\/,]/g, ' ').split(/\s+/).filter((w) => w.length > 2 && !STOP_WORDS.has(w));
  }
  const currentKeywords = new Set(keywords(current.theme));

  const scored = CHAPTERS_DATA
    .filter((c) => c.file !== current.file)
    .map((c) => {
      let score = 0;
      if (c.type === current.type) score += 2;
      const shared = keywords(c.theme).filter((w) => currentKeywords.has(w));
      score += shared.length;
      return { chapter: c, score };
    })
    .sort((a, b) => b.score - a.score || a.chapter.no - b.chapter.no)
    .slice(0, 3);

  if (!scored.length) { section.remove(); return; }

  grid.innerHTML = scored.map(({ chapter }) => `
    <a class="related-card" href="${chapter.file}">
      <span class="related-card-badge">${chapter.type}</span>
      <span class="related-card-title">${chapter.title}</span>
    </a>`).join('');
});
