/* ==========================================================================
   Vocabulary Bank page logic (vocabulary.html)
   - VOCAB_CORE (from vocab-data.js) = words auto-collected from all chapters
   - localStorage 'myVocab' = words the student adds manually, with examples
   ========================================================================== */
document.addEventListener('DOMContentLoaded', () => {
  if (typeof VOCAB_CORE === 'undefined') return;
  const srs = typeof VocabSRS !== 'undefined' ? VocabSRS : null;

  const STORAGE_KEY = 'myVocab';
  const SEED_FLAG = 'myVocabSeed_batch1';
  const SEED_WORDS = [
    { word: "Callous", meaning: "Cold-hearted; lacking empathy." },
    { word: "Hubris", meaning: "Extreme, foolish pride." },
    { word: "Megalomania", meaning: "Obsession with power." },
    { word: "Machiavellian", meaning: "Cunning, scheming, and ruthless." },
    { word: "Poignant", meaning: "Deeply moving, emotional, or sad." },
    { word: "Sardonic", meaning: "Grimly mocking or highly sarcastic." },
    { word: "Ameliorate", meaning: "To improve or make a bad situation better." },
    { word: "Pragmatic", meaning: "Practical; dealing with reality, not just theories." },
    { word: "Juxtapose", meaning: "To place side-by-side to show a contrast." },
    { word: "Dichotomy", meaning: "A sharp division between two opposite things." },
    { word: "Ambiguity", meaning: "Uncertainty or multiple meanings." },
    { word: "Vitiate", meaning: "To spoil, impair, or destroy the quality of." },
    { word: "Obliterate", meaning: "To destroy utterly; wipe out." },
    { word: "Exacerbate", meaning: "To make a bad situation much worse." },
    { word: "Insidious", meaning: "Subtly dangerous; slowly causing harm." },
    { word: "Pervasive", meaning: "Spreading widely into every part of something." },
    { word: "Impetus", meaning: "The driving force or motivation." },
    { word: "Panacea", meaning: "A perfect, magical cure-all solution (usually used to say one doesn't exist)." },
    { word: "Inevitable", meaning: "Unavoidable; certain to happen." },
    { word: "Epiphany", meaning: "A sudden, striking realization." },
    { word: "Transience", meaning: "Lasting only for a short time; not permanent." },
    { word: "Visage", meaning: "A person's face or facial expression." },
    { word: "Filial", meaning: "The duty and respect a child owes to a parent." }
  ];

  function loadMine() {
    try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]'); }
    catch (e) { return []; }
  }
  function saveMine(list) { localStorage.setItem(STORAGE_KEY, JSON.stringify(list)); }

  /* Runs once per browser: merges the starter batch into My Words without
     duplicating anything already there (by word, case-insensitive), and
     never runs again after — so later deletions by the student stick. */
  function seedOnce() {
    if (localStorage.getItem(SEED_FLAG)) return;
    const mine = loadMine();
    const existing = new Set(mine.map((w) => w.word.toLowerCase()));
    let added = 0;
    SEED_WORDS.forEach((w) => {
      if (existing.has(w.word.toLowerCase())) return;
      mine.push({ id: Date.now() + added, word: w.word, meaning: w.meaning, example: '', addedAt: new Date().toISOString() });
      existing.add(w.word.toLowerCase());
      added++;
    });
    if (added) saveMine(mine);
    localStorage.setItem(SEED_FLAG, 'true');
  }
  seedOnce();

  function allEntries() {
    const mine = loadMine().map((w) => ({ ...w, source: 'mine' }));
    return VOCAB_CORE.concat(mine);
  }

  let state = { search: '', filter: 'all' };

  const listEl = document.getElementById('vb-list');
  const emptyEl = document.getElementById('vb-empty');
  const filtersEl = document.getElementById('vb-filters');
  const searchEl = document.getElementById('vb-search');

  /* ---------- Build chapter filter chips from whatever chapters exist ---------- */
  function buildChapterChips() {
    const chapters = [...new Set(VOCAB_CORE.map((e) => e.chapter))].sort((a, b) => a - b);
    chapters.forEach((num) => {
      const btn = document.createElement('button');
      btn.className = 'vb-filter-chip';
      btn.dataset.filter = 'ch' + num;
      btn.textContent = 'Ch ' + num;
      filtersEl.appendChild(btn);
    });
  }

  /* ---------- "Due Today" chip (spaced repetition) ---------- */
  function buildDueChip() {
    if (!srs) return;
    const btn = document.createElement('button');
    btn.className = 'vb-filter-chip vb-filter-chip-due';
    btn.dataset.filter = 'due';
    btn.textContent = 'Due Today';
    filtersEl.insertBefore(btn, filtersEl.querySelector('[data-filter="mine"]').nextSibling);
  }

  /* ---------- Render ---------- */
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  function render() {
    const entries = allEntries();
    const q = state.search.trim().toLowerCase();
    const srsState = srs ? srs.load() : null;

    let filtered = entries.filter((e) => {
      if (state.filter === 'mine' && e.source !== 'mine') return false;
      if (state.filter === 'due') {
        if (!srsState || !srs.isDue(srsState, e.word)) return false;
      }
      if (state.filter.startsWith('ch')) {
        const num = parseInt(state.filter.slice(2), 10);
        if (e.source === 'mine' || e.chapter !== num) return false;
      }
      if (q && !(e.word.toLowerCase().includes(q) || e.meaning.toLowerCase().includes(q))) return false;
      return true;
    });

    filtered.sort((a, b) => a.word.localeCompare(b.word));

    document.getElementById('vb-stat-total').textContent = entries.length;
    document.getElementById('vb-stat-chapters').textContent = new Set(VOCAB_CORE.map((e) => e.chapter)).size;
    document.getElementById('vb-stat-mine').textContent = loadMine().length;
    const dueStatEl = document.getElementById('vb-stat-due');
    if (dueStatEl && srs) {
      dueStatEl.textContent = srs.dueCount(entries.map((e) => e.word));
    }

    if (!filtered.length) {
      listEl.innerHTML = '';
      emptyEl.style.display = 'block';
      return;
    }
    emptyEl.style.display = 'none';

    listEl.innerHTML = filtered.map((e) => {
      const tag = e.source === 'mine'
        ? '<span class="vb-tag mine">★ Mine</span>'
        : '<span class="vb-tag">Ch ' + e.chapter + '</span>';
      const dueTag = (srsState && srs.hasHistory(srsState, e.word) && srs.isDue(srsState, e.word))
        ? '<span class="vb-tag due">Due</span>'
        : '';
      const example = e.example
        ? '<div class="vb-example">' + escapeHtml(e.example) + '</div>'
        : '';
      const deleteBtn = e.source === 'mine'
        ? '<div class="vb-card-actions"><button data-delete="' + e.id + '"><i data-lucide="trash-2"></i> Remove</button></div>'
        : '';
      return (
        '<div class="vb-card">' +
          '<div class="vb-card-top"><span class="vb-word">' + escapeHtml(e.word) + '</span><span class="vb-card-tags">' + tag + dueTag + '</span></div>' +
          '<div class="vb-meaning">' + escapeHtml(e.meaning) + '</div>' +
          example +
          deleteBtn +
        '</div>'
      );
    }).join('');

    if (window.lucide) lucide.createIcons();

    listEl.querySelectorAll('[data-delete]').forEach((btn) => {
      btn.addEventListener('click', () => {
        const id = btn.getAttribute('data-delete');
        const mine = loadMine().filter((w) => String(w.id) !== String(id));
        saveMine(mine);
        render();
      });
    });
  }

  /* ---------- Search + filters ---------- */
  searchEl.addEventListener('input', () => { state.search = searchEl.value; render(); });
  filtersEl.addEventListener('click', (e) => {
    const btn = e.target.closest('.vb-filter-chip');
    if (!btn) return;
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    btn.classList.add('active');
    state.filter = btn.dataset.filter;
    render();
  });

  /* ---------- Add-word modal ---------- */
  const modalBackdrop = document.getElementById('vb-modal-backdrop');
  const openBtn = document.getElementById('vb-add-open');
  const cancelBtn = document.getElementById('vb-modal-cancel');
  const saveBtn = document.getElementById('vb-modal-save');
  const wordInput = document.getElementById('vb-input-word');
  const meaningInput = document.getElementById('vb-input-meaning');
  const exampleInput = document.getElementById('vb-input-example');

  function openModal() {
    wordInput.value = ''; meaningInput.value = ''; exampleInput.value = '';
    modalBackdrop.classList.add('open');
    setTimeout(() => wordInput.focus(), 50);
  }
  function closeModal() { modalBackdrop.classList.remove('open'); }

  openBtn.addEventListener('click', openModal);
  cancelBtn.addEventListener('click', closeModal);
  modalBackdrop.addEventListener('click', (e) => { if (e.target === modalBackdrop) closeModal(); });

  /* ---------- Bulk-paste modal ---------- */
  const bulkBackdrop = document.getElementById('vb-bulk-modal-backdrop');
  const bulkOpenBtn = document.getElementById('vb-bulk-open');
  const bulkCancelBtn = document.getElementById('vb-bulk-cancel');
  const bulkSaveBtn = document.getElementById('vb-bulk-save');
  const bulkInput = document.getElementById('vb-bulk-input');
  const bulkPreview = document.getElementById('vb-bulk-preview');

  /* Parses lines like:
       Callous: Cold-hearted; lacking empathy.
       o **Hubris:** Extreme, foolish pride.
       Poignant: Deeply moving || She gave a poignant speech.
     Skips section headings (no content after the colon, or a word part
     that's clearly a sentence rather than a term) and blank lines. */
  function parseBulkText(text) {
    const lines = text.split('\n');
    const parsed = [];
    lines.forEach((raw) => {
      let line = raw.trim();
      if (!line) return;
      line = line.replace(/^[-•*o○►▸]\s+/, '').replace(/^\d+[\.\)]\s+/, '');
      line = line.replace(/\*\*/g, '');
      const colonIdx = line.indexOf(':');
      if (colonIdx === -1) return;
      const wordPart = line.slice(0, colonIdx).trim();
      let restPart = line.slice(colonIdx + 1).trim();
      if (!wordPart || !restPart) return;
      if (wordPart.split(/\s+/).length > 4) return; // likely a heading/sentence, not a term
      let example = '';
      const exampleSplit = restPart.split('||');
      if (exampleSplit.length > 1) {
        restPart = exampleSplit[0].trim();
        example = exampleSplit.slice(1).join('||').trim();
      }
      if (!restPart) return;
      parsed.push({ word: wordPart, meaning: restPart, example });
    });
    return parsed;
  }

  function updateBulkPreview() {
    const parsed = parseBulkText(bulkInput.value);
    bulkPreview.innerHTML = parsed.length
      ? '<b>' + parsed.length + '</b> word' + (parsed.length === 1 ? '' : 's') + ' detected — headings and blank lines are skipped automatically.'
      : 'Paste your list above — one word per line.';
  }

  function openBulkModal() {
    bulkInput.value = '';
    updateBulkPreview();
    bulkBackdrop.classList.add('open');
    setTimeout(() => bulkInput.focus(), 50);
  }
  function closeBulkModal() { bulkBackdrop.classList.remove('open'); }

  bulkOpenBtn.addEventListener('click', openBulkModal);
  bulkCancelBtn.addEventListener('click', closeBulkModal);
  bulkBackdrop.addEventListener('click', (e) => { if (e.target === bulkBackdrop) closeBulkModal(); });
  bulkInput.addEventListener('input', updateBulkPreview);

  bulkSaveBtn.addEventListener('click', () => {
    const parsed = parseBulkText(bulkInput.value);
    if (!parsed.length) { closeBulkModal(); return; }
    const mine = loadMine();
    const existing = new Set(mine.map((w) => w.word.toLowerCase()));
    let added = 0;
    parsed.forEach((w, i) => {
      if (existing.has(w.word.toLowerCase())) return;
      mine.push({ id: Date.now() + i, word: w.word, meaning: w.meaning, example: w.example, addedAt: new Date().toISOString() });
      existing.add(w.word.toLowerCase());
      added++;
    });
    saveMine(mine);
    closeBulkModal();
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    filtersEl.querySelector('[data-filter="mine"]').classList.add('active');
    state.filter = 'mine';
    render();
  });

  saveBtn.addEventListener('click', () => {
    const word = wordInput.value.trim();
    const meaning = meaningInput.value.trim();
    const example = exampleInput.value.trim();
    if (!word || !meaning) {
      wordInput.style.borderColor = word ? '' : 'var(--danger)';
      meaningInput.style.borderColor = meaning ? '' : 'var(--danger)';
      return;
    }
    const mine = loadMine();
    mine.push({ id: Date.now(), word, meaning, example, addedAt: new Date().toISOString() });
    saveMine(mine);
    closeModal();
    // Jump to "My Words" so the student sees what they just added
    filtersEl.querySelectorAll('.vb-filter-chip').forEach((c) => c.classList.remove('active'));
    filtersEl.querySelector('[data-filter="mine"]').classList.add('active');
    state.filter = 'mine';
    render();
  });

  buildDueChip();
  buildChapterChips();
  render();

  /* ---------- Export / Import backup ---------- */
  document.getElementById('vb-export').addEventListener('click', () => {
    const mine = loadMine();
    const blob = new Blob([JSON.stringify({ exportedAt: new Date().toISOString(), words: mine }, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const stamp = new Date().toISOString().slice(0, 10);
    a.href = url;
    a.download = 'my-vocab-backup-' + stamp + '.json';
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  });

  const importInput = document.getElementById('vb-import-file');
  document.getElementById('vb-import').addEventListener('click', () => importInput.click());
  importInput.addEventListener('change', () => {
    const file = importInput.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const data = JSON.parse(reader.result);
        const incoming = Array.isArray(data) ? data : (Array.isArray(data.words) ? data.words : null);
        if (!incoming) throw new Error('Unrecognised backup format');
        const mine = loadMine();
        const existing = new Set(mine.map((w) => w.word.toLowerCase()));
        let added = 0;
        incoming.forEach((w, i) => {
          if (!w || !w.word || !w.meaning) return;
          if (existing.has(String(w.word).toLowerCase())) return;
          mine.push({ id: Date.now() + i, word: w.word, meaning: w.meaning, example: w.example || '', addedAt: w.addedAt || new Date().toISOString() });
          existing.add(String(w.word).toLowerCase());
          added++;
        });
        saveMine(mine);
        render();
        alert(added + ' word' + (added === 1 ? '' : 's') + ' imported' + (incoming.length - added > 0 ? ' (' + (incoming.length - added) + ' already existed, skipped)' : '') + '.');
      } catch (e) {
        alert("Couldn't read that file — make sure it's a backup exported from this page.");
      }
      importInput.value = '';
    };
    reader.readAsText(file);
  });
});
