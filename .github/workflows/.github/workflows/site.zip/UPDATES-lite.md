# English Notes (public lite version)
- Same as the full site but without the English Grammar section.
- Own cache name: english-lite-v1.
