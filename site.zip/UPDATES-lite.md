# English Notes (public lite version)
- Same as the full site but without the English Grammar section.
- Own cache name: english-lite-v1.
- Home page: new "Install this app" card with an Install button. Cache: english-lite-v2.
