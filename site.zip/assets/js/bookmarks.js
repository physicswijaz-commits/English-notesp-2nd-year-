/* ==========================================================================
   My Bookmarks — pulls every point highlighted via highlight.js (stored
   per-page under 'highlights:<page>') into one revision list. Since
   highlight.js only stores block *indices* per page, this re-fetches each
   chapter's HTML (already precached by the service worker, so it works
   offline too) and re-runs the same selector to recover the text.
   ========================================================================== */
document.addEventListener('DOMContentLoaded', async () => {

  const listEl = document.getElementById('bm-list');
  const emptyEl = document.getElementById('bm-empty');
  const statPoints = document.getElementById('bm-stat-points');
  const statChapters = document.getElementById('bm-stat-chapters');
  if (!listEl) return;

  const HL_SELECTOR = 'section.topic p, section.topic li';

  /* ---------- Gather every "highlights:<page>" key from localStorage ---------- */
  const pages = [];
  for (let i = 0; i < localStorage.length; i++) {
    const raw = localStorage.key(i);
    if (!raw || raw.indexOf('en:highlights:') !== 0) continue;
    const key = raw.slice(3);
    let indices = [];
    try { indices = JSON.parse(localStorage.getItem(key) || '[]'); } catch (e) { indices = []; }
    if (!indices.length) continue;
    pages.push({ page: key.slice('highlights:'.length), indices: new Set(indices) });
  }

  if (!pages.length) {
    emptyEl.style.display = '';
    return;
  }

  /* Sort chapters into natural order: ch1, ch2, ... ch19. */
  pages.sort((a, b) => {
    const na = parseInt((a.page.match(/\d+/) || ['0'])[0], 10);
    const nb = parseInt((b.page.match(/\d+/) || ['0'])[0], 10);
    return na - nb;
  });

  /* ---------- Fetch each chapter, recover title/theme + the bookmarked text ---------- */
  async function loadPage({ page, indices }) {
    try {
      const res = await fetch(page);
      if (!res.ok) return null;
      const html = await res.text();
      const doc = new DOMParser().parseFromString(html, 'text/html');

      const titleEl = doc.querySelector('.chapter-header h1');
      const themeEl = doc.querySelector('.chapter-header p');
      const blocks = Array.from(doc.querySelectorAll(HL_SELECTOR));

      const points = [];
      indices.forEach((idx) => {
        const block = blocks[idx];
        if (block) points.push({ index: idx, text: block.textContent.trim() });
      });
      if (!points.length) return null;

      return {
        page,
        title: titleEl ? titleEl.textContent.trim() : page,
        theme: themeEl ? themeEl.textContent.trim() : '',
        points,
      };
    } catch (e) {
      return null; /* offline + not cached, or page missing — skip quietly */
    }
  }

  const groups = (await Promise.all(pages.map(loadPage))).filter(Boolean);

  if (!groups.length) {
    emptyEl.style.display = '';
    return;
  }

  /* ---------- Render ---------- */
  let totalPoints = 0;
  const frag = document.createDocumentFragment();

  groups.forEach((group) => {
    totalPoints += group.points.length;

    const card = document.createElement('div');
    card.className = 'bm-lesson-card';

    const head = document.createElement('a');
    head.className = 'bm-lesson-head';
    head.href = group.page;
    head.innerHTML =
      '<span class="bm-lesson-badge"><i data-lucide="book-text"></i>Ch. ' + (group.page.match(/\d+/) || ['?'])[0] + '</span>' +
      '<span class="bm-lesson-title">' + group.title + '</span>' +
      (group.theme ? '<span class="bm-lesson-theme">' + group.theme + '</span>' : '') +
      '<i data-lucide="arrow-right" class="bm-lesson-arrow"></i>';
    card.appendChild(head);

    const ul = document.createElement('ul');
    ul.className = 'bm-points';
    group.points.forEach((pt) => {
      const li = document.createElement('li');
      li.className = 'bm-point';
      const span = document.createElement('span');
      span.className = 'bm-point-text';
      span.textContent = pt.text;
      const removeBtn = document.createElement('button');
      removeBtn.className = 'bm-point-remove';
      removeBtn.setAttribute('aria-label', 'Remove bookmark');
      removeBtn.innerHTML = '<i data-lucide="x"></i>';
      removeBtn.addEventListener('click', () => {
        removeHighlight(group.page, pt.index);
        li.remove();
        const remaining = ul.querySelectorAll('.bm-point').length;
        if (!remaining) card.remove();
        updateStats(-1);
        if (!document.querySelector('.bm-point')) emptyEl.style.display = '';
      });
      li.appendChild(span);
      li.appendChild(removeBtn);
      ul.appendChild(li);
    });
    card.appendChild(ul);
    frag.appendChild(card);
  });

  listEl.appendChild(frag);
  if (window.lucide) lucide.createIcons();

  statPoints.textContent = totalPoints;
  statChapters.textContent = groups.length;

  function updateStats(delta) {
    statPoints.textContent = Math.max(0, parseInt(statPoints.textContent, 10) + delta);
  }

  function removeHighlight(page, index) {
    const key = 'highlights:' + page;
    try {
      const set = new Set(JSON.parse(localStorage.getItem(key) || '[]'));
      set.delete(index);
      localStorage.setItem(key, JSON.stringify([...set]));
    } catch (e) { /* ignore */ }
  }
});
