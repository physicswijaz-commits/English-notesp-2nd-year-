/* اردو نوٹس — runs after sign-in: loads the protected lesson text from the database, then starts the site scripts. */
(function(){
'use strict';
var MQ=window.MQ=window.MQ||{};
var listEl=document.getElementById('mq-list'); if(!listEl) return;
var list=JSON.parse(listEl.textContent), page=document.body.getAttribute('data-mqpage')||'';
function fail(msg){
  var m=document.querySelector('main')||document.body;
  m.innerHTML='<div style="padding:40px 18px;text-align:center;line-height:2"><p>'+msg+'</p><button onclick="location.reload()" style="padding:10px 18px;border-radius:12px;border:1px solid var(--border);background:var(--surface);color:var(--text);font:inherit;cursor:pointer">دوبارہ کوشش کریں</button></div>';
}
function loadScript(src){ return new Promise(function(res){ var s=document.createElement('script'); s.src=src; s.async=false; s.onload=res; s.onerror=function(){ res(); }; document.body.appendChild(s); }); }
function runText(t){ var s=document.createElement('script'); s.text=t; document.body.appendChild(s); }
MQ.authReady.then(async function(){
  if(page){
    var o=await MQ.fetchDoc('en_'+page);
    if(!o||!o.html){ fail('یہ سبق لوڈ نہیں ہو سکا۔ انٹرنیٹ چیک کریں؛ پہلی بار کھولنے کے لیے انٹرنیٹ درکار ہے۔'); return; }
    document.querySelector('main').innerHTML=o.html;
  }
  /* the site scripts expect to start at DOMContentLoaded/load; those events have passed, so replay them afterwards */
  var q=[], dEA=document.addEventListener, wEA=window.addEventListener;
  document.addEventListener=function(t,f,o){ if(t==='DOMContentLoaded'&&typeof f==='function'){ q.push([document,f,t]); return; } return dEA.apply(this,arguments); };
  window.addEventListener=function(t,f,o){ if(t==='load'&&typeof f==='function'){ q.push([window,f,t]); return; } return wEA.apply(this,arguments); };
  try{
    for(var i=0;i<list.length;i++){
      var it=list[i];
      if(it.s) await loadScript(it.s);
      else if(it.p){ var d=await MQ.fetchDoc(it.p); if(d&&d.t) runText(d.t); }
      else if(it.i) runText(it.i);
    }
  } finally { document.addEventListener=dEA; window.addEventListener=wEA; }
  q.forEach(function(x){ try{ x[1].call(x[0],new Event(x[2])); }catch(e){ console.error(e); } });
  /* the install prompt fired before extras.js was loaded; hand it over now so the settings-panel install button works too */
  var o=window.__mqInstall; if(o){ var fe=new Event('beforeinstallprompt'); fe.prompt=function(){ return o.prompt(); }; fe.userChoice=o.userChoice; try{ window.dispatchEvent(fe); }catch(e){} }
});
})();
