/* Edit "goatcounter" to your GoatCounter code to turn on visitor stats. */
window.COMMUNITY={
 "url": "https://physicswijaz-commits.github.io/English-notesp-2nd-year-/",
 "wa": "923409368103",
 "goatcounter": "",
 "S": {
  "share": "Share",
  "whatsnew": "What's new",
  "report": "Report a mistake",
  "share_title": "Share this site",
  "share_p": "Send the site to a friend. After opening the link they will need to sign in and be approved by the admin.",
  "wa_btn": "Share on WhatsApp",
  "sys_btn": "Share…",
  "copy_btn": "Copy link",
  "copied": "Link copied",
  "qr_title": "Scan to open",
  "qr_p": "Show this code to a classmate and they can scan it with their phone camera.",
  "share_msg": "English Notes for KPK Board 2nd Year: ",
  "report_msg": "Mistake report",
  "back": "Back",
  "new_title": "What's new",
  "new_intro": "Recent changes to the site, newest first.",
  "dismiss": "Dismiss",
  "tab": "Share"
 }
};
