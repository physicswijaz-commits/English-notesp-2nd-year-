/* "Install app" button (shared). Captures the browser's install prompt as early as possible, and shows a button at the end of the
   footer links on every page until the app is installed. Without a prompt (iPhone, or Chrome not ready yet) it shows short instructions. */
(function(){
'use strict';
if(window.MQ_INST) return; window.MQ_INST=1;
var ev=window.__mqInstall||null;
function standalone(){ try{ return matchMedia('(display-mode: standalone)').matches||navigator.standalone===true; }catch(e){ return false; } }
function done(){ try{ return localStorage.getItem('mq_installed')==='1'; }catch(e){ return false; } }
function installed(){ return standalone()||done(); }
addEventListener('beforeinstallprompt',function(e){ e.preventDefault(); ev=e; window.__mqInstall=e; });
addEventListener('appinstalled',function(){ ev=null; window.__mqInstall=null; try{ localStorage.setItem('mq_installed','1'); }catch(e){} refresh(); });
if(standalone()){ try{ localStorage.setItem('mq_installed','1'); }catch(e){} }
var ios=/iphone|ipad|ipod/i.test(navigator.userAgent);
function help(){
  var o=document.createElement('div'); o.style.cssText='position:fixed;inset:0;z-index:99995;display:grid;place-items:center;padding:20px;background:rgba(10,20,15,.5)';
  var msg=ios?'سفاری میں نیچے «شیئر» کا بٹن دبائیں، پھر «ہوم اسکرین میں شامل کریں» چنیں۔':'براؤزر کے مینو (⋮) میں «ایپ انسٹال کریں» یا «ہوم اسکرین میں شامل کریں» چنیں۔';
  o.innerHTML='<div role="dialog" style="max-width:340px;width:100%;background:var(--white,var(--surface,#fff));color:var(--text,#14231C);border-radius:20px;padding:22px 18px;text-align:center;line-height:2;font-family:inherit;box-shadow:0 20px 60px rgba(0,0,0,.35)"><b style="font-size:1.1rem">ایپ انسٹال کریں</b><p style="margin:8px 0 14px;font-size:.95rem"></p><button type="button" style="min-height:44px;padding:8px 28px;border:0;border-radius:12px;background:var(--btn,var(--primary,#2A7459));color:#fff;font:inherit;font-weight:600;cursor:pointer">ٹھیک ہے</button></div>';
  o.querySelector('p').textContent=msg; o.onclick=function(e){ if(e.target===o||e.target.tagName==='BUTTON') o.remove(); }; document.body.appendChild(o);
}
async function go(e){
  if(e) e.preventDefault();
  var p=ev; if(!p){ help(); return; }
  try{ p.prompt(); var r=await p.userChoice; if(r&&r.outcome==='accepted'){ try{ localStorage.setItem('mq_installed','1'); }catch(x){} } }catch(x){}
  ev=null; window.__mqInstall=null; refresh();
}
function refresh(){
  var a=document.getElementById('mq-inst');
  if(installed()){ if(a) a.remove(); return; }
  var nav=document.querySelector('.site-foot nav'); if(!nav) return;
  if(!a){ a=document.createElement('a'); a.id='mq-inst'; a.href='#'; a.setAttribute('role','button'); a.textContent='ایپ انسٹال کریں'; a.onclick=go; }
  if(nav.lastElementChild!==a) nav.appendChild(a);
}
var n=0; (function t(){ refresh(); if(++n<60) setTimeout(t,500); })();
window.MQ_INSTALL={ prompt:go, refresh:refresh };
})();
