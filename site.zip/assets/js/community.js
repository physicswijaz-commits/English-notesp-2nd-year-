/* Community features: announcement banner, report-a-mistake, share/what's new links, optional visitor stats. */
(function(){
var C=window.COMMUNITY||{},S=C.S||{};
var page=(location.pathname.split('/').pop()||'index.html');
function esc(t){var d=document.createElement('div');d.textContent=t;return d.innerHTML;}
/* 1. Visitor stats (GoatCounter) — only when a code is set in site-config */
if(C.goatcounter){var g=document.createElement('script');g.async=true;g.src='https://gc.zgo.at/count.js';g.setAttribute('data-goatcounter','https://'+C.goatcounter+'.goatcounter.com/count');document.head.appendChild(g);}
/* 2. Announcement banner on the home page */
function banner(){
  if(page!=='index.html'&&page!=='')return;
  var main=document.querySelector('main');if(!main||!window.fetch)return;
  fetch('announcement.json',{cache:'no-store'}).then(function(r){return r.ok?r.json():null;}).then(function(a){
    if(!a||!a.text||!String(a.text).trim())return;
    var id=String(a.id||a.text);try{if(localStorage.getItem('ann_dismissed')===id)return;}catch(e){}
    var d=document.createElement('div');d.setAttribute('role','status');
    d.style.cssText='margin:12px 0;padding:12px 14px;border-radius:16px;background:var(--primary-light);display:flex;align-items:flex-start;gap:10px';
    d.innerHTML='<div style="flex:1;min-width:0;line-height:1.6">'+esc(a.text)+'</div><button type="button" aria-label="'+esc(S.dismiss||'Dismiss')+'" style="border:0;background:none;font:inherit;font-weight:700;cursor:pointer;color:inherit;padding:0 4px">✕</button>';
    d.querySelector('button').onclick=function(){try{localStorage.setItem('ann_dismissed',id);}catch(e){}d.remove();};
    main.insertBefore(d,main.firstChild);
  }).catch(function(){});
}
/* 3. Footer links: Share, What's new, Report a mistake */
function footer(){
  var nav=document.querySelector('.site-foot nav');if(!nav||nav.getAttribute('data-comm'))return false;
  nav.setAttribute('data-comm','1');
  var t=(document.title||page).split(/\s[|—-]\s/)[0];
  var msg=(S.report_msg||'Mistake report')+' - '+t+' ('+page+'): ';
  var h=[['share.html',S.share],['whatsnew.html',S.whatsnew],['https://wa.me/'+C.wa+'?text='+encodeURIComponent(msg),S.report]];
  h.forEach(function(x){var a=document.createElement('a');a.href=x[0];a.textContent=x[1];if(x[0].indexOf('http')===0){a.target='_blank';a.rel='noopener noreferrer';}nav.appendChild(a);});
  return true;
}
function start(){var tries=0;(function t(){if(footer()||++tries>20)return;setTimeout(t,250);})();}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',start);else start();
/* Share page helpers (share.html) */
window.CommunityShare={
  url:C.url,
  wa:function(){return 'https://wa.me/?text='+encodeURIComponent((S.share_msg||'')+C.url);},
  native:function(){if(navigator.share)navigator.share({title:document.title,text:S.share_msg||'',url:C.url}).catch(function(){});else window.open(this.wa(),'_blank');},
  copy:function(btn){var t=C.url,done=function(){var o=btn.textContent;btn.textContent=S.copied;setTimeout(function(){btn.textContent=o;},1800);};
    if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,function(){});}
    else{var i=document.createElement('input');i.value=t;document.body.appendChild(i);i.select();try{document.execCommand('copy');done();}catch(e){}document.body.removeChild(i);}}
};
})();
